import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const required = ['VITE_FIREBASE_API_KEY=AIzaSyCyMFIy1hDL4xIt88tPva0Cd6C-Jd-0VkQ
VITE_FIREBASE_AUTH_DOMAIN=udaancreditaryan.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=udaancreditaryan
VITE_FIREBASE_APP_ID=1:150203705594:web:fc01e8f658e273f1da4143] as const;
const missing = required.filter((key) => !import.meta.env[key]);
export const firebaseConfigured = missing.length === 0;
const config = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};
// Firebase web config is public configuration; authorization must be enforced by Rules/backend.
const app = initializeApp({ ...config, apiKey: config.apiKey || 'not-configured' });
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
